<?php
// Heading
$_['heading_title']         	= 'Fulfillment by Amazon';
$_['text_openbay']				= 'OpenBay Pro';
$_['text_dashboard']			= 'Fulfillment by Amazon Dashboard';

// Text
$_['text_heading_settings'] 	= 'Settings';
$_['text_heading_account'] 		= 'Account/subscription';
$_['text_heading_fulfillments'] = 'Fulfillments';
$_['text_heading_register'] 	= 'Register';
$_['text_heading_orders'] 		= 'Orders';