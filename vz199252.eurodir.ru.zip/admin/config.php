<?php
// HTTP
define('HTTP_SERVER', 'http://vz199252.eurodir.ru/admin/');
define('HTTP_CATALOG', 'http://vz199252.eurodir.ru/');

// HTTPS
define('HTTPS_SERVER', 'http://vz199252.eurodir.ru/admin/');
define('HTTPS_CATALOG', 'http://vz199252.eurodir.ru/');

// DIR
define('DIR_APPLICATION', '/var/www/anton/data/www/vz199252.eurodir.ru/admin/');
define('DIR_SYSTEM', '/var/www/anton/data/www/vz199252.eurodir.ru/system/');
define('DIR_IMAGE', '/var/www/anton/data/www/vz199252.eurodir.ru/image/');
define('DIR_LANGUAGE', '/var/www/anton/data/www/vz199252.eurodir.ru/admin/language/');
define('DIR_TEMPLATE', '/var/www/anton/data/www/vz199252.eurodir.ru/admin/view/template/');
define('DIR_CONFIG', '/var/www/anton/data/www/vz199252.eurodir.ru/system/config/');
define('DIR_CACHE', '/var/www/anton/data/www/vz199252.eurodir.ru/system/storage/cache/');
define('DIR_DOWNLOAD', '/var/www/anton/data/www/vz199252.eurodir.ru/system/storage/download/');
define('DIR_LOGS', '/var/www/anton/data/www/vz199252.eurodir.ru/system/storage/logs/');
define('DIR_MODIFICATION', '/var/www/anton/data/www/vz199252.eurodir.ru/system/storage/modification/');
define('DIR_UPLOAD', '/var/www/anton/data/www/vz199252.eurodir.ru/system/storage/upload/');
define('DIR_CATALOG', '/var/www/anton/data/www/vz199252.eurodir.ru/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'anton');
define('DB_PASSWORD', '89048512165');
define('DB_DATABASE', 'anton');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
